--CRUD
                                                        --SELECT--
CREATE PROC GETALLORDERDETAIL
AS
SELECT * FROM [Order Details]
GO
                                                       --SELECT 2--
CREATE PROC GETALLORDERS
AS
SELECT * FROM Orders
GO
                                                          --ADD--
ALTER PROC ADDORDERDETAIL @CITY NVARCHAR(15) , @COUNTRY NVARCHAR(15) 
AS 
INSERT INTO Orders( ShipCity , ShipCountry)
VALUES ( @CITY , @COUNTRY)
GO
                                                         --UPDATE--
CREATE PROC UPDATEORDER @ORDERID INT , @CITY NVARCHAR
AS 
UPDATE Orders
SET ShipCity = @CITY
WHERE OrderID = @ORDERID

                                                         --DELETE--
ALTER PROC DELETEORDERDETAILL  @ORDERID INT
AS
DELETE FROM Orders  WHERE OrderID = @ORDERID
DELETE FROM [Order Details]
WHERE OrderID =  @ORDERID
GO